export const configuration = {
    callType: {
        GET: 'get',
        POST: 'post'
      },
      urlMappings:{
          getStockDetails:"",
          predictModelOutPut:"/uploadfiles/"
      }
  };
  