import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

const routes: Routes = [{
  path: 'stockProjection',
  loadChildren: () => import('./modules/stock-projection/stock-projection.module').then(m => m.StockProjectionModule),
  data: {
    title: ''
  }
},
{
  path: 'upload',
  loadChildren: () => import('./modules/upload/upload.module').then(m => m.UploadModule),
  data: {
    title: ''
  }
}]

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
