import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import {StockProjectionComponent} from './stock-projection.component'
import { from } from 'rxjs';

const stockExchangeRoutes: Routes = [{
  path: '',
  component: StockProjectionComponent
}];
@NgModule({
  declarations: [StockProjectionComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(stockExchangeRoutes)
  ]
})
export class StockProjectionModule { }
