import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UploadComponent } from '../upload/upload.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import {TableModule} from 'primeng/table';
const uploadRoutes: Routes = [{
  path: '',
  component: UploadComponent
}];

@NgModule({
  declarations: [UploadComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(uploadRoutes),
    FormsModule, 
    ReactiveFormsModule,
    MatTableModule,
    TableModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class UploadModule { }
