import { Component, OnInit, AfterViewInit, ViewChild} from '@angular/core';
import { from } from 'rxjs';
import {UploadService} from './upload.service';
import { FormBuilder, FormGroup } from "@angular/forms";
import {MatTableModule} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})

export class UploadComponent implements OnInit {
  form : FormGroup
  modelOutput : any
  displayedColumns: string[] = ['confidenceValue','predictedLabel'];
  dataSource: MatTableDataSource<any>;

  classificationModelOP : any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(
    public fb: FormBuilder,private uploadService: UploadService) { 
      this.form = this.fb.group({
        file: [null]
      })
      
    }

  ngOnInit(): void {
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  handleFileInput(event){
    console.log(event.target.files[0])
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    this.uploadService.getStockDetails(formData).subscribe(modelOutput => {
      
      this.modelOutput = {
        "labels":modelOutput.body['labels'],
        "confidence":JSON.parse(modelOutput.body['confidence'])
      }
      console.log(this.modelOutput);
    });
  }
  upload(event) {
    const file = (event.target as HTMLInputElement).files[0];
    this.form.patchValue({
      file: file
    });
    this.form.get('file').updateValueAndValidity()
 }
 submit() {
  var formData: any = new FormData();
  formData.append("file", this.form.get('file').value);

  this.uploadService.getStockDetails(formData).subscribe(modelOutput => {
   // console.log(modelOutput.body['labels'].split(""))
    this.modelOutput = {
      "confidence":modelOutput.body['confidence']
    }
    console.log(this.modelOutput);
    let dataSourceArr = [];
    this.modelOutput['confidence'].forEach(mapper => {
      dataSourceArr.push(this.createDatasource(mapper));

    })
    this.classificationModelOP = dataSourceArr;
    //this.dataSource = new MatTableDataSource(dataSourceArr);
    //console.log(this.dataSource)

  });
}
 createDatasource(confidenceValue) {
  
  return {
    confidenceValue: confidenceValue,
    predictedLabel: confidenceValue > 0.73 ? 'True' : 'False'
  }

}
}
