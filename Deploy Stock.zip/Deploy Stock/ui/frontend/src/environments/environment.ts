export const environment = {
  deploymentFeature: 'rdl',
  production: false,
  // serviceURL: 'http://localhost/api',
  //serviceURL: 'http://localhost:8000',
  serviceURL: 'http://notebook'
};